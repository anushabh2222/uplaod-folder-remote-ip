package com.oauthserver;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

public class Upload {
	public static void main(String[] args) {
        String localPath = "C:\\Users\\anusha_hosamani\\Downloads\\name"; //add the folder to be upload path
        String fileName =  "name.zip";  //add folder name ex;name.zip
        String sftpPath = "/home/user/freshers-task/";   //directory for uploading a folder inside server
        String sftpHost = "172.30.66.175";  //ip address
        String sftpPort = "22";             //port no
        String sftpUser = "user";     //username
        String sftpPassword = "123!";  //password

        try{
            /**
             * Open session to sftp server
             */
            JSch jsch = new JSch();
            Session session = jsch.getSession(sftpUser, sftpHost, Integer.valueOf(sftpPort));
            session.setConfig("StrictHostKeyChecking", "no");
            session.setPassword(sftpPassword);
            System.out.println("Connecting------");
            session.connect();
            System.out.println("Established Session");

            Channel channel = session.openChannel("sftp");
            ChannelSftp sftpChannel = (ChannelSftp) channel;
            sftpChannel.connect();

            System.out.println("Opened sftp Channel");

            /**
             * Do everything you need in sftp
             */
            System.out.println("Copying file to Host");
            sftpChannel.put(localPath+"/"+fileName, sftpPath);
            System.out.println("Copied file to Host");

            System.out.println("Copying file from Host to Local");
            sftpChannel.get(sftpPath+"/"+fileName, localPath);
            System.out.println("Copied file from Host to local");

            sftpChannel.disconnect();
            session.disconnect();

            System.out.println("Disconnected from sftp");

        } catch(Exception e) {
            e.printStackTrace();
        }
    }

}





